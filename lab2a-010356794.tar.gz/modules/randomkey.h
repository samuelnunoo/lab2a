#include <stddef.h>

void random_key(char *dest, size_t length);